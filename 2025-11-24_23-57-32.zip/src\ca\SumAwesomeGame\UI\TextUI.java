package ca.SumAwesomeGame.UI;

/**
 * Displays the welcome message when the game starts.
 * 
 * @author Sum Awesome Game Team
 */
public class TextUI {
    public TextUI() {
        System.out.println("***************************************************");
        System.out.println("*** Welcome to Sum Awesome game by Arun & Surya ***");
        System.out.println("***************************************************");
    }
}
